import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../plat_form_details.dart';

class CardPostWidget extends StatefulWidget {
  const CardPostWidget({Key? key}) : super(key: key);

  @override
  _CardPostWidgetState createState() => _CardPostWidgetState();
}

class _CardPostWidgetState extends State<CardPostWidget> {
  @override
  Widget build(BuildContext context) {
    var sizeH = MediaQuery.of(context).size.height;
    var sizeW = MediaQuery.of(context).size.width;
    return Stack(
      children: [
        Container(
          height: sizeH * 0.6,
          width: sizeW * 0.85,
          decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(40),
                topRight: Radius.circular(40),
              )),
          child: Column(
            children: [
              Container(
                  height: sizeH * 0.1,
                  child: Padding(
                    padding: EdgeInsets.only(left: sizeW * 0.05),
                    child: Row(
                      children: [
                        CircleAvatar(
                          backgroundColor: Colors.transparent,
                          child: Image.asset("assets/images/profilePic.png"),
                        ),
                        Text(
                          "Sam Guy",
                          style: GoogleFonts.inter(
                            textStyle: const TextStyle(
                                fontWeight: FontWeight.bold,
                                color: const Color(0xFF000000),
                                fontSize: 16),
                          ),
                        ),
                        Text(
                          "@samguy",
                          style: GoogleFonts.inter(
                            textStyle: const TextStyle(
                                color: const Color(0xFF536471), fontSize: 16),
                          ),
                        )
                      ],
                    ),
                  )),
              Container(
                  color: Color(0xFF0076C9),
                  height: sizeH * 0.35,
                  width: sizeW,
                  child: Padding(
                    padding: EdgeInsets.only(),
                    child: Image.asset(
                      "assets/images/postImgCat.png",
                      fit: BoxFit.fitWidth,
                    ),

                  )),
              SizedBox(
                height: sizeH * 0.02,
              ),
              Padding(
                padding: EdgeInsets.only(left: sizeW * 0.05),
                child: Row(
                  children: [
                    Text(
                      "Sam Guy",
                      style: GoogleFonts.inter(
                        textStyle: const TextStyle(
                            fontWeight: FontWeight.bold,
                            color: const Color(0xFF000000),
                            fontSize: 16),
                      ),
                    ),
                    Text(
                      "@samguy",
                      style: GoogleFonts.inter(
                        textStyle: const TextStyle(
                            color: const Color(0xFF536471), fontSize: 16),
                      ),
                    )
                  ],
                ),
              ),
              SizedBox(
                height: sizeH * 0.005,
              ),
              Padding(
                padding: EdgeInsets.only(left: sizeW * 0.05),
                child: Row(
                  children: [
                    Container(
                      width: isMobile(context)
                    ? sizeW * 0.6
                    : 200 + sizeW * 0.0,
                      // color: Colors.red,
                      child: Text(
                        "My new refsheet is finally complete! ",
                        style: TextStyle(fontSize: 14),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: sizeH * 0.005,
              ),
              Padding(
                padding: EdgeInsets.only(left: sizeW * 0.05, right: sizeW * 0.05),
                child: Row(
                  children: [
                    Image.asset(
                      "assets/images/heartIcon.png",
                      color: Color(0xFF536471),
                      height: 25,
                    ),
                    Text(
                      "100",
                      style: GoogleFonts.inter(
                        textStyle: const TextStyle(
                            color: const Color(0xFF000000), fontSize: 16),
                      ),
                    ),
                    Spacer(),
                    Image.asset(
                      "assets/images/messageIcon.png",
                      color: Color(0xFF536471),
                      height: 25,
                    ),
                    Text(
                      "100",
                      style: GoogleFonts.inter(
                        textStyle: const TextStyle(
                            color: const Color(0xFF000000), fontSize: 16),
                      ),
                    ),
                    Spacer(),
                    Image.asset(
                      "assets/images/listIconPOst.png",
                      color: Color(0xFF536471),
                      height: 25,
                    ),
                    Text(
                      "100",
                      style: GoogleFonts.inter(
                        textStyle: const TextStyle(
                            color: Color(0xFF000000), fontSize: 16),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        )
      ],
    );
  }
}