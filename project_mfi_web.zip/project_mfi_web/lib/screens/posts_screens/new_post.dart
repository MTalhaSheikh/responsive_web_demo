import 'package:flutter/material.dart';
import 'package:project_mfi_web/screens/posts_screens/upload_image.dart';

class NewPostScreen extends StatefulWidget {
  const NewPostScreen({Key? key}) : super(key: key);

  @override
  _NewPostScreenState createState() => _NewPostScreenState();
}

class _NewPostScreenState extends State<NewPostScreen> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return SafeArea(
      child: Scaffold(
        backgroundColor: const Color(0xffaa0633),
        body: SizedBox(
          height: size.height,
          width: size.width,
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(
                      Icons.arrow_back_ios,
                      color: Colors.white,
                    ),
                    Image.asset(
                      "assets/images/myfi.png",
                      height: 30,
                      width: 60,
                    )
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 50.0),
                  child: SizedBox(
                      width: size.width * 0.7,
                      child: const FittedBox(
                          fit: BoxFit.cover,
                          child: Text(
                            "Ooooo, time for a \npost?",
                            style: TextStyle(color: Colors.white),
                          ))),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 80.0),
                  child: Align(
                      alignment: Alignment.centerRight,
                      child: Image.asset(
                        "assets/images/app_pic.png",
                        height: 150,
                        width: 150,
                      )),
                ),
                Center(
                  child: SizedBox(
                    height: 60,
                      width: size.width * 0.9,
                      // color: const Color(0xffd9d9d9),
                      child: ElevatedButton(
                        style: ButtonStyle(
                          backgroundColor:  MaterialStateProperty.all<Color>(const Color(0xffd9d9d9)) ,
                        ),
                    onPressed: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => const UploadImage()));
                    },
                    child: const Text("New post", style: TextStyle(fontSize: 15, color: Colors.black54),),
                  )),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 12.0),
                  child: Center(
                    child: SizedBox(
                        height: 60,
                        width: size.width * 0.9,
                        // color: const Color(0xffd9d9d9),
                        child: ElevatedButton(
                          style: ButtonStyle(
                            backgroundColor:  MaterialStateProperty.all<Color>(const Color(0xffd9d9d9)) ,
                          ),
                          onPressed: () {},
                          child: const Text("New OC", style: TextStyle(fontSize: 15, color: Colors.black54),),
                        )),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
