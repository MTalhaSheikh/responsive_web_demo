import 'package:flutter/material.dart';
import 'package:project_mfi_web/screens/posts_screens/posted_screen.dart';

class AddLocation extends StatefulWidget {
  const AddLocation({Key? key}) : super(key: key);

  @override
  _AddLocationState createState() => _AddLocationState();
}

class _AddLocationState extends State<AddLocation> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return SafeArea(
      child: Scaffold(
        backgroundColor: const Color(0xffaa0633),
        body: SizedBox(
          height: size.height,
          width: size.width,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                height: 70,
                width: size.width,
                color: const Color(0xffaa0633),
                child: Padding(
                  padding: const EdgeInsets.only(left: 12.0, right: 12.0),
                  child: Row(
                    children: [
                      InkWell(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: const Padding(
                          padding: EdgeInsets.all(8.0),
                          child: Icon(
                            Icons.arrow_back_ios,
                            color: Colors.white,
                            size: 15,
                          ),
                        ),
                      ),
                      Image.asset(
                        "assets/images/myfi.png",
                        height: 30,
                        width: 60,
                      ),
                      const Spacer(),
                      GestureDetector(
                        onTap: (){
                          // Navigator.push(context, MaterialPageRoute(builder: (context) => const PostedScreen()));
                        },
                        child: const Text(
                          "Next",
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 17,
                              fontWeight: FontWeight.w600),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 22.0, right: 22.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text(
                      "Add Location",
                      style: TextStyle(
                          fontSize: 27,
                          color: Colors.white,
                          fontWeight: FontWeight.w700),
                    ),
                    Spacer(),
                    Image.asset(
                      "assets/images/profile.png",
                      height: 50,
                      width: 50,
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: Row(
                  children: const [
                    Text(
                      "Conventions",
                      style: TextStyle(color: Colors.white70, fontSize: 18),
                    ),
                    Spacer(),
                    Text(
                      "Locations",
                      style: TextStyle(color: Colors.white70, fontSize: 18),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 20.0),
                child: Container(
                  height: 40,
                  width: size.width * 0.9,
                  decoration: BoxDecoration(
                    color: const Color(0xffa0053a),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.only(left: 8.0),
                    child: Row(
                      children: const [
                        Icon(
                          Icons.search,
                          color: Colors.white70,
                        ),
                        Padding(
                          padding: EdgeInsets.only(left: 8.0),
                          child: Text(
                            "Search",
                            style: TextStyle(color: Colors.white70),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              listWidget("M", "BLFC", "@art", Color(0xfff8ad13)),
              listWidget("F", "CFZ", "@frenchies", Color(0xff0013f0)),
              listWidget("F", "FWA", "@Oliver", Color(0xff6a14fc)),
            ],
          ),
        ),
      ),
    );
  }
}

Widget listWidget(mainText, heading, detail, colorss) {
  return Padding(
    padding: const EdgeInsets.only(left: 25.0, top: 20),
    child: Row(
      children: [
        CircleAvatar(
          radius: 25,
          backgroundColor: colorss,
          child: Text(
            mainText,
            style: const TextStyle(
                fontSize: 30, color: Colors.white, fontWeight: FontWeight.w600),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(left: 15.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                heading,
                style: const TextStyle(
                    fontSize: 18,
                    color: Colors.white,
                    fontWeight: FontWeight.w500),
              ),
              Text(
                detail,
                style: const TextStyle(
                  fontSize: 14,
                  color: Colors.white,
                ),
              )
            ],
          ),
        )
      ],
    ),
  );
}
