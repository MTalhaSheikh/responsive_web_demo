package com.example.project_mfi_web

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
