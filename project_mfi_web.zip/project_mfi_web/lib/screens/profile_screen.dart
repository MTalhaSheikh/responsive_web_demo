import 'package:flutter/material.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import '../plat_form_details.dart';
import '../widgets/dot_indecator.dart';
import '../widgets/profile_screen_widgets.dart';
import '../widgets/post_widget.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    _tabController = TabController(length: 3, vsync: this);
    super.initState();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return SafeArea(
      child: Scaffold(
        backgroundColor: isMobile(context) ? const Color(0xff222222): const Color(0xff2c2a31),
        body: SingleChildScrollView(
          child: Column(
            children: [
              Container(
                height: isMobile(context) ? 40 : 45,
                width: size.width,
                decoration: const BoxDecoration(
                  color:  Color(0xffA0003A),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black,
                      blurRadius: 3.0,
                      spreadRadius: 0.0,
                      offset:
                          Offset(2.0, 2.0), // shadow direction: bottom right
                    )
                  ],
                ),
                child: Padding(
                  padding:
                      EdgeInsets.only(left: isMobile(context) ? 25.0 : 100.0),
                  child: Align(
                      alignment: Alignment.centerLeft,
                      child: SizedBox(
                        height: 25,
                        width: 50,
                        child: FittedBox(
                            fit: BoxFit.contain,
                            child: Image.asset("assets/images/myfi.png")),
                      )),
                ),
              ),
              Container(
                height: isMobile(context) ? 60 : 60,
                width: size.width,
                color: isMobile(context)
                    ? const Color(0xffA0003A)
                    : const Color(0xff8a0838),
                // : const Color.fromRGBO(160, 0, 58, 0.93),
                child: isMobile(context)
                    ? Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          signupBarText(context),
                          Padding(
                            padding:
                                const EdgeInsets.only(left: 20.0, top: 5.0),
                            child: signupBtnText(context),
                          )
                        ],
                      )
                    : Row(
                        children: [
                          Visibility(
                            visible: isMobile(context) ? false : true,
                            child: Padding(
                              padding: const EdgeInsets.only(left: 15.0),
                              child: Align(
                                  alignment: Alignment.centerLeft,
                                  child: SizedBox(
                                    height: 60,
                                    width: 70,
                                    child: FittedBox(
                                        fit: BoxFit.contain,
                                        child: Image.asset(
                                            "assets/images/app_pic.png")),
                                  )),
                            ),
                          ),
                          signupBarText(context),
                          const Spacer(),
                          signupBtnText(context)
                        ],
                      ),
              ),
              Stack(
                children: [
                  Container(
                    height: isMobile(context) ? 150 : 250,
                    width: size.width,
                    decoration: const BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage("assets/images/bg.png"),
                        fit: BoxFit.fill,
                      ),
                    ),
                    child: Padding(
                      padding: isMobile(context)
                          ? const EdgeInsets.all(8.0)
                          : const EdgeInsets.only(right: 50.0, top: 8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Align(
                              alignment: isMobile(context)
                                  ? Alignment.topLeft
                                  : Alignment.bottomLeft,
                              child: Padding(
                                padding: isMobile(context)
                                    ? const EdgeInsets.all(8.0)
                                    : const EdgeInsets.only(
                                        left: 80.0, bottom: 8.0),
                                child: artistWidget(),
                              )),
                          const Spacer(),
                          optionWidget(Icons.more_horiz),
                          Padding(
                            padding: const EdgeInsets.only(left: 4.0),
                            child: optionWidget(Icons.upload_outlined),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 88.0),
                    child: Center(
                      child: Column(
                        children: [
                          Image.asset(
                            "assets/images/profile.png",
                            height: 100,
                            width: 100,
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Text(
                              "Jordskull",
                              style: TextStyle(
                                  fontSize: isMobile(context) ? 14 : 17,
                                  color: Colors.white),
                            ),
                          )
                        ],
                      ),
                    ),
                  )
                ],
              ),
              Row( mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Column(
                    mainAxisAlignment: isMobile(context)
                        ? MainAxisAlignment.center
                        : MainAxisAlignment.start,
                    crossAxisAlignment: isMobile(context)
                        ? CrossAxisAlignment.center
                        : CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: EdgeInsets.only(
                            top: isMobile(context) ? 0 : 10.0,
                            left: isMobile(context) ? 0 : size.width * 0.22),
                        child: Row(
                          mainAxisAlignment: isMobile(context)
                              ? MainAxisAlignment.center
                              : MainAxisAlignment.start,
                          children: const [
                            Text(
                              "@Jordskull",
                              style: TextStyle(color: Colors.white70, fontSize: 10),
                            ),
                            SizedBox(
                              width: 40,
                            ),
                            Text(
                              "fursona.is/jordskull",
                              style: TextStyle(color: Colors.white70, fontSize: 10),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                            top: isMobile(context) ? 0 : 10.0,
                            left: isMobile(context) ? 0 : size.width * 0.18),
                        child: TabBar(
                          controller: _tabController,
                          indicatorSize: TabBarIndicatorSize.tab,
                          indicator: const DotIndicator(
                            color: Colors.white,
                            radius: 3,
                          ),
                          isScrollable: true,
                          labelColor: Colors.white,
                          unselectedLabelColor: Colors.white,
                          labelStyle: TextStyle(
                              fontSize: isMobile(context) ? 14 : 17,
                              fontWeight: FontWeight.w600),
                          unselectedLabelStyle: TextStyle(
                              fontSize: isMobile(context) ? 14 : 17,
                              fontWeight: FontWeight.w400),
                          tabs: <Widget>[
                            const Tab(text: 'Links'),
                            Padding(
                              padding: EdgeInsets.only(
                                  left: size.width * 0.04,
                                  right: size.width * 0.04),
                              child: const Tab(text: 'Posts'),
                            ),
                            const Tab(text: 'OCs'),
                          ],
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                            top: isMobile(context) ? 10.0 : 15.0,
                            left: isMobile(context) ? 0 : size.width * 0.25),
                        child: Row(
                          mainAxisAlignment: isMobile(context)
                              ? MainAxisAlignment.center
                              : MainAxisAlignment.start,
                          children: [
                            followerInfoWidget("150", "Following"),
                            const SizedBox(
                              width: 60,
                            ),
                            followerInfoWidget("323", "Followers"),
                          ],
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                            top: 15.0,
                            left: isMobile(context) ? 0 : size.width * 0.15),
                        child: Container(
                          height: size.height,
                          width: isMobile(context)
                              ? size.width * 0.8
                              : 200 + size.width * 0.15,
                          child: TabBarView(controller: _tabController, children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text(
                                    "Jordskull here. Welcome to my page. Have a good time! Here’s where you can reach me... Read more",
                                    style: TextStyle(color: Colors.white, letterSpacing: 0.6, fontSize: 13),
                                    textAlign: TextAlign.center,
                                  ),
                                  SizedBox(height: isMobile(context) ? 20 : 30,),

                                  SizedBox(
                                    height: 40,
                                      width: isMobile(context)
                                          ? size.width * 0.8
                                          : 200 + size.width * 0.15,
                                      child: primaryRedButton(),),

                                  const SizedBox(height: 22),
                                  const Text("Other URLs:", style: TextStyle(color: Colors.white, fontSize: 14),),
                                  const SizedBox(height: 22),
                                  primaryEditBlackButton("edit_icon1.png", "Tap to edit", context, size),
                                  const SizedBox(height: 15),
                                  primaryEditBlackButton("msg_icon.png", "Tap to edit", context, size),
                                  const SizedBox(height: 15),
                                  primaryEditBlackButton("", "Tap to edit", context, size),

                                  const SizedBox(height: 22),
                                  const Text("Add more links:", style: TextStyle(color: Colors.white, fontSize: 14),),
                                  const SizedBox(height: 22),
                                  primaryLinksBlackButton("LinkIcon.png", "Website", context, size),
                                  const SizedBox(height: 15),
                                  primaryLinksBlackButton("DiscordIcon.png", "Discord", context, size),
                                  const SizedBox(height: 15),
                                  primaryLinksBlackButton("instagramIcon.png", "Instagram", context, size),
                                  const SizedBox(height: 15),
                                  primaryLinksBlackButton("youtube.png", "YouTube chanel", context, size),
                                  const SizedBox(height: 15),
                                  primaryLinksBlackButton("facebookIcon.png", "Facebook", context, size),

                                ],
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                children: const [
                                  Padding(
                                    padding: EdgeInsets.all(20.0),
                                    child: CardPostWidget(),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              height: 50,
                              width: 50,
                              color: Colors.blueGrey,
                            ),
                          ]),
                        ),
                      )
                    ],
                  ),
                  isMobile(context) ? Container() : Spacer(),
                  isMobile(context) ? Container() : Padding(
                    padding: EdgeInsets.only(top: 60.0, right: size.width * 0.10),
                    child: Container(
                      height: size.width * 0.26,
                      width: size.width * 0.26,
                      color: Colors.black45,
                      child: StaggeredGrid.count(
                        crossAxisCount: 3,
                        mainAxisSpacing: 3,
                        crossAxisSpacing: 2,
                        children: [
                          StaggeredGridTile.count(
                            crossAxisCellCount: 1,
                            mainAxisCellCount: 2,
                            child: Container(
                              color: Colors.black45,
                                child: FittedBox(
                                  fit: BoxFit.fill,
                                    child: Image.asset("assets/images/post1.png"))),
                          ),
                          StaggeredGridTile.count(
                            crossAxisCellCount: 1,
                            mainAxisCellCount: 1,
                            child: Container(
                                color: Colors.black45,
                                child: FittedBox(
                                    fit: BoxFit.fill,
                                    child: Image.asset("assets/images/post2.png"))),
                          ),
                          StaggeredGridTile.count(
                            crossAxisCellCount: 1,
                            mainAxisCellCount: 1,
                            child: Container(
                                color: Colors.black45,
                                child: FittedBox(
                                    fit: BoxFit.fill,
                                    child: Image.asset("assets/images/post3.png"))),
                          ),
                          StaggeredGridTile.count(
                            crossAxisCellCount: 1,
                            mainAxisCellCount: 1,
                            child: Container(
                                color: Colors.black45,
                                child: FittedBox(
                                    fit: BoxFit.fill,
                                    child: Image.asset("assets/images/post4.png"))),
                          ),
                          StaggeredGridTile.count(
                            crossAxisCellCount: 1,
                            mainAxisCellCount: 1,
                            child: Container(
                                color: Colors.black45,
                                child: FittedBox(
                                    fit: BoxFit.fill,
                                    child: Image.asset("assets/images/post5.png"))),
                          ),
                          StaggeredGridTile.count(
                            crossAxisCellCount: 1,
                            mainAxisCellCount: 1,
                            child: Container(
                                color: Colors.black45,
                                child: FittedBox(
                                    fit: BoxFit.fill,
                                    child: Image.asset("assets/images/post6.png"))),
                          ),
                          StaggeredGridTile.count(
                            crossAxisCellCount: 2,
                            mainAxisCellCount: 1,
                            child: Container(
                                color: Colors.black45,
                                child: FittedBox(
                                    fit: BoxFit.fill,
                                    child: Image.asset("assets/images/post7.png"))),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
