import 'package:flutter/material.dart';

import '../plat_form_details.dart';

Widget signupBarText(context) {
  return Padding(
    padding: const EdgeInsets.only(left: 25.0),
    child: Container(
      width: isMobile(context) ? 290 : 170,
      child: Text(
        "One place for your art, fursonas, OCs, and links. Easily shareable. For free.",
        style: isMobile(context)
            ? const TextStyle(color: Colors.white70, fontSize: 12)
            : const TextStyle(color: Colors.white70, fontSize: 9),
      ),
    ),
  );
}

Widget signupBtnText(context) {
  return Padding(
    padding: const EdgeInsets.only(right: 50.0),
    child: SizedBox(
      height: 20,
      width: 50,
      child: FittedBox(
          fit: BoxFit.contain,
          child: Image.asset("assets/images/gredent_btn.png")),
    ),
  );
}

Widget optionWidget(icon) {
  return CircleAvatar(
    backgroundColor: Colors.grey[900],
    radius: 12,
    child: Icon(
      icon,
      color: Colors.white70,
      size: 16,
    ),
  );
}

Widget artistWidget() {
  return Row(
    children: const [
      Icon(
        Icons.brush,
        color: Colors.white,
        size: 15,
      ),
      Padding(
        padding: EdgeInsets.all(4.0),
        child: Text(
          "Artist",
          style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w500,
              letterSpacing: 1.0,
              fontSize: 10),
        ),
      ),
    ],
  );
}

Widget followerInfoWidget(countText, text) {
  return Column(
    children: [
      Text(
        countText,
        style: const TextStyle(
            fontSize: 20, fontWeight: FontWeight.w800, color: Colors.white),
      ),
      Text(
        text,
        style: const TextStyle(fontSize: 9, color: Colors.white),
      )
    ],
  );
}

Widget primaryRedButton() {
  return ElevatedButton(
    style: ElevatedButton.styleFrom(
        primary: const Color(0xffef5d60),
        //background color of button
        // side: BorderSide(width:3, color:Colors.brown), //border width and color
        elevation: 3,
        //elevation of button
        shape: RoundedRectangleBorder(
            //to set border radius to button
            borderRadius: BorderRadius.circular(10)),
        padding: EdgeInsets.all(12) //content padding inside button
        ),
    onPressed: () {},
    child: Row(
      children: const [
        CircleAvatar(
            radius: 12,
            backgroundColor: Colors.white,
            child: Center(
                child: Icon(
              Icons.send,
              size: 12,
              color: Color(0xffef5d60),
            ))),
        Padding(
          padding: EdgeInsets.only(left: 20.0),
          child: Text(
            "Open for commissions!",
            style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
          ),
        ),
      ],
    ),
  );
}

Widget primaryEditBlackButton(icon, text, context, size) {
  return SizedBox(
    height: 40,
    width: isMobile(context)
        ? size.width * 0.8
        : 200 + size.width * 0.15,
    child: ElevatedButton(
      style: ElevatedButton.styleFrom(
          primary: Colors.grey[800],
          //background color of button
          // side: BorderSide(width:3, color:Colors.brown), //border width and color
          elevation: 3,
          //elevation of button
          shape: RoundedRectangleBorder(
              //to set border radius to button
              borderRadius: BorderRadius.circular(10)),
          padding: EdgeInsets.all(12) //content padding inside button
          ),
      onPressed: () {},
      child: Padding(
        padding: const EdgeInsets.only(left: 8.0),
        child: Row(
          children: [
            icon != "" ? Image.asset(
              "assets/images/$icon",
              height: 15,
              width: 15,
              color: Colors.white,
            ): const SizedBox(height: 15,
            width: 15,),
            Padding(
              padding: const EdgeInsets.only(left: 20.0),
              child: Text(
                text,
                style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
              ),
            ),
            const Spacer(),
            Image.asset(
              "assets/images/export.png",
              height: 20,
              width: 20,
              color: Colors.white,
            ),
          ],
        ),
      ),
    ),
  );
}

Widget primaryLinksBlackButton(icon, text, context, size) {
  return SizedBox(
    height: 40,
    width: isMobile(context)
        ? size.width * 0.8
        : 200 + size.width * 0.15,
    child: ElevatedButton(
      style: ElevatedButton.styleFrom(
          primary: Colors.grey[800],
          //background color of button
          // side: BorderSide(width:3, color:Colors.brown), //border width and color
          elevation: 3,
          //elevation of button
          shape: RoundedRectangleBorder(
            //to set border radius to button
              borderRadius: BorderRadius.circular(10)),
          padding: EdgeInsets.all(12) //content padding inside button
      ),
      onPressed: () {},
      child: Padding(
        padding: const EdgeInsets.only(left: 8.0),
        child: Row(
          children: [
            icon != "" ? Image.asset(
              "assets/images/$icon",
              height: 15,
              width: 15,
              color: Colors.white,
            ): const SizedBox(height: 15,
              width: 15,),
            Padding(
              padding: const EdgeInsets.only(left: 20.0),
              child: Text(
                text,
                style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
              ),
            ),
          ],
        ),
      ),
    ),
  );
}
