import 'package:flutter/material.dart';
import 'package:project_mfi_web/screens/posts_screens/posted_screen.dart';
import 'package:project_mfi_web/screens/posts_screens/tag_user.dart';

import 'add_location.dart';

class FeedPost extends StatefulWidget {
  const FeedPost({Key? key}) : super(key: key);

  @override
  _FeedPostState createState() => _FeedPostState();
}

class _FeedPostState extends State<FeedPost> {
  String dropdownValue = "Visibility";

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return SafeArea(
      child: Scaffold(
        backgroundColor: const Color(0xffaa0633),
        body: SizedBox(
          height: size.height,
          width: size.width,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                height: 70,
                width: size.width,
                color: const Color(0xffaa0633),
                child: Padding(
                  padding: const EdgeInsets.only(left: 12.0, right: 12.0),
                  child: Row(
                    children: [
                      InkWell(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: const Padding(
                          padding: EdgeInsets.all(8.0),
                          child: Icon(
                            Icons.arrow_back_ios,
                            color: Colors.white,
                            size: 15,
                          ),
                        ),
                      ),
                      Image.asset(
                        "assets/images/myfi.png",
                        height: 30,
                        width: 60,
                      ),
                      const Spacer(),
                      const Text(
                        "Post",
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 17,
                            fontWeight: FontWeight.w600),
                      ),
                      GestureDetector(
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => const PostedScreen()));
                        },
                        child: const Padding(
                          padding: EdgeInsets.all(8.0),
                          child: Icon(
                            Icons.arrow_forward_ios,
                            color: Colors.white,
                            size: 15,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 22.0, right: 22.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text(
                      "Feed post",
                      style: TextStyle(
                          fontSize: 27,
                          color: Colors.white,
                          fontWeight: FontWeight.w700),
                    ),
                    Spacer(),
                    Image.asset(
                      "assets/images/profile.png",
                      height: 50,
                      width: 50,
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 20.0),
                child: Container(
                  height: size.height * 0.25,
                  width: size.width,
                  color: const Color(0xffd9d9d9),
                  child: Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text("How are you feeling?"),
                        Spacer(),
                        Row(
                          children: [
                            Container(
                              height: size.width * 0.15,
                              width: size.width * 0.15,
                              decoration: BoxDecoration(
                                  border: Border.all(
                                    color:
                                        Colors.black54, // red as border color
                                  ),
                                  borderRadius: const BorderRadius.all(
                                      Radius.circular(10.0))),
                              child: const Icon(
                                Icons.upload_outlined,
                                color: Colors.black54,
                                size: 30,
                              ),
                            ),
                            containerWidget(size),
                            containerWidget(size),
                            containerWidget(size),
                            containerWidget(size),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const Padding(
                padding: EdgeInsets.all(20.0),
                child: Text(
                  "To add hashtags, just type them! We’ll sort \nthem automatically.",
                  style: TextStyle(fontSize: 15, color: Colors.white),
                ),
              ),

              GestureDetector(
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context) => const TagUser()));
                },
                child: Padding(
                  padding: const EdgeInsets.only(left: 20.0),
                  child: Row(
                    children: const [
                      CircleAvatar(
                        radius: 18,
                        backgroundColor: Colors.white,
                        child: Icon(Icons.person, color: Color(0xffaa0633), size: 30,),
                      ),
                      Padding(
                        padding: EdgeInsets.only(left: 8.0),
                        child: Text("Tag user", style: TextStyle(fontSize: 18, color: Colors.white, fontWeight: FontWeight.w500),),
                      ),
                    ],
                  ),
                ),
              ),

              GestureDetector(
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context) => const AddLocation()));
                },
                child: Padding(
                  padding: const EdgeInsets.only(left: 20.0, top: 22),
                  child: Row(
                    children: const [
                      Icon(Icons.location_on, color: Colors.white, size: 35,),
                      Padding(
                        padding: EdgeInsets.only(left: 8.0),
                        child: Text("Add Location", style: TextStyle(fontSize: 18, color: Colors.white, fontWeight: FontWeight.w500),),
                      ),
                    ],
                  ),
                ),
              ),

              Padding(
                padding: const EdgeInsets.only(top: 10.0, left: 17),
                child: Row(
                  children: [
                    const Icon(Icons.arrow_drop_down, size: 40, color: Colors.white,),
                    Padding(
                      padding: const EdgeInsets.only(left: 5.0),
                      child: DropdownButton<String>(
                        value: dropdownValue,
                        dropdownColor: Color(0xffaa0633),
                        icon: const Icon(Icons.arrow_downward, color: Color(0xffaa0633),),
                        iconSize: 24,
                        elevation: 16,
                        style: const TextStyle(
                            fontSize: 18, color: Colors.white, fontWeight: FontWeight.w500
                        ),
                        underline: Container(
                          height: 2,
                          color: Color(0xffaa0633),
                        ),
                        onChanged: (String? newValue) {
                          setState(() {
                            dropdownValue = newValue!;
                          });
                        },
                        items: <String>['Visibility', 'Public', 'Private', 'Unlisted']
                            .map<DropdownMenuItem<String>>((String value) {
                          return DropdownMenuItem<String>(
                            value: value,
                            child: Text(value,),
                          );
                        })
                            .toList(),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

Widget containerWidget(size) {
  return Padding(
    padding: const EdgeInsets.only(left: 8.0),
    child: Container(
      height: size.width * 0.15,
      width: size.width * 0.15,
      decoration: BoxDecoration(
          border: Border.all(
            color: Colors.black54, // red as border color
          ),
          borderRadius: const BorderRadius.all(Radius.circular(10.0))),
      // child: const Icon(Icons.upload_outlined, color: Colors.black54, size: 30,),
    ),
  );
}
